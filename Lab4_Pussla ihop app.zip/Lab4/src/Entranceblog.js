import React, { useState } from 'react';
import { StyleSheet, TextInput,View, Text,SafeAreaView, Button, TouchableWithoutFeedbackBase } from 'react-native';
const Entrance = () => {
    var UsernameRoot ="admin";
    var PaswordRoot="admin";
    const [username,setUser]=useState("");
    const [pasword,setPass]=useState("");
    const [textinlogad,setTextinlogad]=useState("You are not inlogad yet");
          
    const logInPress= () =>  {
        if ((UsernameRoot==username)&&( PaswordRoot==pasword ) ){
            setTextinlogad("Now you are in");
        }else setTextinlogad("You are not inlogad yet");
    }
return (
    <View style={styles.containerEntrance} > 
        <View style={styles.square2}>
        <View style={styles.square1}>
            <View >
            <Text style={styles.textcolorEntrance}>Welcome to your Lucky Cyber Blog </Text>
            </View>
         </View >
        </View>  
        <View>
            <Text style={styles.logaText}>Hi, Login Here </Text>
            <SafeAreaView>     
            <Text style={styles.userInfoText}>Username:
            <TextInput style={{backgroundColor:"grey"}}  placeholder="Type your username " onChangeText={setUser} />   
            </Text>  
            <Text style={styles.userInfoText}>Password: 
            <TextInput style={{backgroundColor:"grey"}} placeholder="Type your password " onChangeText={setPass} />
            </Text>  
            </SafeAreaView>    
            <View>
            <Button  title="Login"  value="loga in" 
            onPress= {logInPress}  />  
            </View>
            <View>
            <Text style={styles.logaStatus} > {textinlogad}   </Text>
            </View>    
        </View>  
        <View >
        <Text style={styles.separator}>-----------------------------------------------------------------------------------------------</Text>
        </View>
    </View>
    );
};
const styles = StyleSheet.create({
    containerEntrance: {
        backgroundColor: 'black',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign:'center',
        flexDirection:'column',
    },
    square1: {
        backgroundColor: "#ffd60a",
        width: 240,
        height: 140,
        margin: 4,
        borderRadius: "5%",
        borderWidth: 4,
        borderColor:"blue",
        
    },
      square2: {
        backgroundColor: "red",
        width: 240,
        height: 140,
        margin: 4,
        borderRadius: "5%",
        borderWidth: 2,
        borderColor:"orange",
    },
    textcolorEntrance: {
        color:"Black",
        textAlign:"center",
        fontSize:"xx-large",
        fontWeight: 'bold',
    },
    logaText:{
        color:"#4cc9f0",
        textAlign:"center",
        fontSize:"x-large",
    },
    userInfoText:{
        color:"white",
        textAlign:"center",
        fontSize:"large",
        height:"35px",
    },
    logaStatus:{
        color:"#4cc9f0",
        textAlign:"center",
        fontSize:"normal",
    },
    separator:{
        backgroundColor:"black", 
        color:"#4cc9f0",
        height:"20px",
    },
});
export default Entrance;