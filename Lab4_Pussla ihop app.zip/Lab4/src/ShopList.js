import React, { useState } from 'react';
import { StyleSheet,View,FlatList, Text,ImageBackground,SafeAreaView, Button, TouchableWithoutFeedbackBase } from 'react-native';

const Shoplist = () => {
const imageLigths= { uri: " https://t2.uc.ltmcdn.com/images/9/1/7/img_42719_apa_276365_600.jpg" };
const controlleraShopGame1 = () =>{
       updateyourlist([...yourlist,shoplist[0]]);
       settadddisabled(true);
       settremovedisabled(false);
}
const controlleraShopGame2 = () =>{
        updateyourlist([...yourlist,shoplist[1]]);
        settadddisabled2(true);
        settremovedisabled(false);
}
const removingLastItem = () =>{
    checklistaStatus();
    updateyourlist(yourlist.slice(0,yourlist.length-1));
}
const checklistaStatus=() => {
    if(yourlist[yourlist.length-1]==shoplist[0])
        settadddisabled(false);
    
    else (settadddisabled2(false));
    if(yourlist.length-1==0)
    settremovedisabled(true);
}    
function setShopMessage() {
    updateshop("Your Shop Is Done!");
    settremovedisabled(true);
}

const[shoplist,updateshoplist]=useState(["Tetrix fight (Deluxe)=50kr","Dead iland (Deluxe)=30kr"]);
const[yourlist,updateyourlist]=useState([]);
const[countgame1,updatecount1]=useState(0);
const [removedisabled,settremovedisabled]=useState(true);
const [adddisabled,settadddisabled]=useState(false);
const [adddisabled2,settadddisabled2]=useState(false);
const[shop,updateshop]=useState("");

return(
<View style={styles.containerTestyourlucky}>
    <View>
    <ImageBackground source={imageLigths} resizeMode="stretch" style={styles.image}>
    <Text style={styles.header1} > BUY VIP GAMES FOR IOS / ANDROID HERE </Text>
    </ImageBackground>
    </View>
    <View style={styles.liststyle}>
           <View>
                <View>
                <Text>  {shoplist[0]} <Button  title="ADD" disabled={adddisabled} onPress=  { controlleraShopGame1 } />       
                </Text>
                </View>
                <View style={styles.listseparator}/>
                <View>
                <Text> {shoplist[1]} <Button  title="ADD" disabled={adddisabled2} onPress=  {controlleraShopGame2} />
                </Text>
                </View>
                <View style={styles.listseparator}/>
            </View>
            <Text>Total Vip games = {shoplist.length}</Text>
    </View>
    <View>
    <Text style={styles.header2}>[ Your shop List ] </Text>
        <View>
            <View style={styles.liststyleyourshop}>
                <FlatList  
                ItemSeparatorComponent={() => <View style={styles.listseparator}> </View>} // en rad    
                List
                data={yourlist}
                renderItem={ (   {item,index } ) =>   (
                <View >            
                <Text>  + {item}           </Text>
                </View>
                )}/>
            </View>
        </View> 
    <Button  title="Remove last item"  disabled={removedisabled} onPress= {removingLastItem }  />
             
    </View>
    <View style={styles.shopstatus}>
        <View>
        <Text> Your Shop status</Text> 
        </View> 
        <View>
        <Text> You will buy : {yourlist.length} Items</Text> 
        </View> 
        <View style={{  margin:"8px"}}>
        <Button  title="Shop now"   disabled={removedisabled} onPress={() => setShopMessage()}  />
        </View>
    </View>               
<View >
<ImageBackground source={imageLigths} resizeMode="cover" style={styles.image}>
    <Text style={styles.shopdone}>{shop}</Text>
    </ImageBackground>
</View>
</View>
);
}
const styles = StyleSheet.create({
    containerTestyourlucky: {
        backgroundColor: 'black',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign:'center',
    },
    liststyle:{
        backgroundColor:"grey",
        borderColor:"white",
        borderWidth:"2px",
        margin:"20px",
        width:"230px"
    },
    liststyleyourshop:{
        backgroundColor:"grey",
        borderColor:"white",
        borderWidth:"2px",
        borderStyle:"solid",
    },
    listseparator:{
        backgroundColor:"black",
        height:"5px"
    },
    header1:{
        color: 'red',
        textAlign: 'center',
        fontSize:'large',
        height:'50px',
        fontWeight: 'bold',
        jusifyContent: "stretch",
        alignItems: "stretch"
    },
    header2:{
        color: 'white',
        textAlign: 'center',
        fontSize:'large',
        height:'50px',
        fontWeight: 'bold',
    },
    shopstatus:{
        backgroundColor: '#f9c2ff',
        borderRadius:"5px",
        borderStyle:"dashed",
        borderColor:"red",
        borderWidth:"5px",
        margin:"20px",
        width:"150px",
    },
    image: {
        flex: 1,
        justifyContent: "center",
    },
    shopdone:{
        color:"#4cc9f0",
        fontSize:"large",
        height:"60px",
        textAlign:"auto",
    },
});
export default Shoplist;
