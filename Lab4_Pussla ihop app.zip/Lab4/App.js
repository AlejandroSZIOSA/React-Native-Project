import { StatusBar } from "expo-status-bar";
import React from "react";
import { StyleSheet, Text, View } from "react-native";
import Activities from "./src/Activities";
import Entrance from "./src/Entranceblog";
import Shoplist from "./src/ShopList";

//Gabriel Alejandro Sazo Seron
export default function App() {
  return (
    <View >
      <Entrance/>
      <Activities/>
      <Shoplist/>
      <StatusBar style="auto" />
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
