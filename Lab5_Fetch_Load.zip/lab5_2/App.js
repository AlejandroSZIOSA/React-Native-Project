import { StatusBar } from 'expo-status-bar';
import React, { useState, useEffect  } from 'react';
import { StyleSheet, Text,FlatList,json, View } from 'react-native';
import LoadIndicator from './src/LoadIndicator';

export default function App() {
//UseEffect function   
useEffect(() => {
  getMovies();
}, []);
function getMovies(){
  //Access to DB json
  fetch("https://reactnative.dev/movies.json")
  //Response control
  .then((response) => response.json())
  //Resultat array json
  .then((json) => {
    for(let i=0; i<json.movies.length; i++)
      tempJsonArray.push({id: json.movies[i].id , title: json.movies[i].title ,releaseyear: json.movies[i].releaseYear});
      
  // Function make a copy Json array object to a array object list
  copyjsontomyobjectArray();
  //Function countdown
  setTimeout(() => {  setloadstate(false);   }, 3000);
})
.catch((e) => console.log(e));
}
const copyjsontomyobjectArray =() =>{
  setjsoncopy(tempJsonArray);
}
//Define some Hooks and array object 
const[loadstate,setloadstate]=useState(true);
const [jsoncopy,setjsoncopy]=useState();
const tempJsonArray=[{}];
return (
<View style={styles.container}>
  <View>
    { loadstate ? (      
    <LoadIndicator />
    ) : (
        <FlatList      
        List
        data={jsoncopy}
        keyExtractor={ ( item ) => item.id  }
        renderItem={ (   {item,index } ) =>   (
        <View >            
        <Text> {item.id}  {item.title} {item.releaseyear}  </Text>
        </View>
      )} /> 
    )}
  </View>   
  <StatusBar style="auto" />
</View>
);
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
