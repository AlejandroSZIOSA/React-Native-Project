import { setStatusBarBackgroundColor, StatusBar } from "expo-status-bar";
import React from "react";
import { StyleSheet, Text,Button, View } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

const Stack = createNativeStackNavigator();

function HomeScreen({navigation}) {
  return (
  <View style={{ flex: 1, justifyContent: "top", alignItems: "center", backgroundColor:"#DFE0DF"}}>
    <View>
      <Text style={{fontFamily: 'Raleway-Bold'}}> Home Navigation </Text>
      <Button color="#17202A" title="to About" onPress={ ()=> navigation.navigate("About")} />       
    </View>  
  </View>
  );
} 
function About({navigation}) {
  return (
  <View style={{flex: 1, justifyContent: "top", alignItems: "center", backgroundColor:"#FEF5E7" }}>
    <View>
    <Text  style={{fontFamily: 'Raleway-Bold'}}  > About Navigation </Text>
    </View>
    <Button color="#17202A" title="to Credits component" onPress={ ()=> navigation.navigate("Credits")} />
  </View>
  );
} 
export default function App() {
  return (
    <NavigationContainer>
    <Stack.Navigator initialRouteName="Home">
    <Stack.Screen name="Home" component={HomeScreen}       
    options={{
        title:"Home", 
        headerStyle:{
          backgroundColor:"#E59866",
        },
        headerTintColor: "#541C00", headerTitleStyle:{
          fontWeight: "bold",
        },
        headerRight:()=>(
          <Button
            onPress={()=>   alert("Info")}
            title="info"
            fontWeight="italic"
            color="#17202A"
          />
        )
    }} 
    />
    <Stack.Screen name="About" component={About} 
    options={{
      title:"About", 
      headerStyle:{
        backgroundColor:"#E59866",
      },
      headerTintColor: "#541C00", headerTitleStyle:{
        fontWeight: "bold",
      },
      headerRight:()=>(
        <Button
          onPress={()=>   alert("Info")  }
          title="info"
          fontWeight="italic"
          color="#17202A"
        />
      )
  }} 
  />
    <Stack.Screen name="Credits" getComponent={()=> require("./src/Credits").default} 
    options={{
      title:"Credits", 
      headerStyle:{
        backgroundColor:"#E59866"
      },
      headerTintColor: "#541C00", headerTitleStyle:{
        fontWeight: "bold"
      },
      headerRight:()=>(
        <Button
          onPress={()=>   alert("Info")  }
          title="info"
          fontWeight="italic"
          color="#17202A"
        />
      )
  }} 
  />
    </Stack.Navigator>
    </NavigationContainer>
);
}
