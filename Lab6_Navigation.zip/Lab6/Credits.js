import React, { Component } from 'react';
import { Button, View, Text, ImageBackground } from 'react-native';

const CreditsComponent = ({navigation}) =>{
return(
<View style={{ flex: 1, alignItems: 'center', justifyContent: 'top', backgroundColor:"#EAECEE" }}>
  <View >
    <Text style={{fontFamily: 'Raleway-Bold'}}>Credits Navigation</Text>
    <Button color="#17202A" title="Back Home" onPress={ ()=> navigation.popToTop() } />
  </View> 
</View>
)}
export default CreditsComponent;